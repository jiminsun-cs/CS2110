
1. Press enter to start the game\
2. You can move around the character using UP,  DOWN, RIGHT, LEFT keys to eat the candy.\
3. The character LOSES when it touches the wall
4. The character will WIN when it eats two candies. The character can eat the same candy twice.
