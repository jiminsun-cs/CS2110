/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 croc croc.png 
 * Time-stamp: Tuesday 04/06/2021, 13:27:56
 * 
 * Image Information
 * -----------------
 * croc.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CROC_H
#define CROC_H

extern const unsigned short croc[100];
#define CROC_SIZE 200
#define CROC_LENGTH 100
#define CROC_WIDTH 10
#define CROC_HEIGHT 10

#endif

