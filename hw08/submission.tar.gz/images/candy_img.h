/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x10 candy_img candy_img.png 
 * Time-stamp: Friday 04/02/2021, 13:40:05
 * 
 * Image Information
 * -----------------
 * candy_img.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CANDY_IMG_H
#define CANDY_IMG_H

extern const unsigned short candy_img[100];
#define CANDY_IMG_SIZE 200
#define CANDY_IMG_LENGTH 100
#define CANDY_IMG_WIDTH 10
#define CANDY_IMG_HEIGHT 10

#endif

